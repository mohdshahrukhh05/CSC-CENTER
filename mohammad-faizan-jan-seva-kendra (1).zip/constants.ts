
import { Translations, Language } from './types';

export const MAPTILER_API_KEY = 'BiowIbnYQSapXeBxzL7t';
export const LOCATION_COORDINATES: [number, number] = [77.3718, 28.6919]; // Approx. coordinates for Noor Nagar, could be refined.

export const translations: Translations = {
  [Language.EN]: {
    nav: {
      home: 'Home',
      services: 'Services',
      team: 'Our Team',
      contact: 'Contact Us',
      requestService: 'Request a Service',
      checkStatus: 'Check Status'
    },
    hero: {
      title: 'Mohammad Faizan Jan Seva Kendra',
      subtitle: 'Your one-stop solution for all CSC and e-District services. Reliable, fast, and efficient.',
      cta: 'Request a Service'
    },
    services: {
      title: 'Our Services',
      items: [
        { title: 'State Bank of India', description: 'All banking services available, including deposits, withdrawals, and account opening.' },
        { title: 'AEPS Services', description: 'Aadhaar Enabled Payment System for easy cash withdrawal, balance inquiry, and mini statements.' },
        { title: 'e-District Services', description: 'Domicile, Caste, and Income Certificates.', price: '₹100 per certificate' },
        { title: 'Lamination', description: 'High-quality lamination for documents.', price: '₹10 per page' },
        { title: 'Xerox / Photocopy', description: 'Clear and fast photocopying.', price: '₹1 / side, ₹2 for both sides' },
        { title: 'Account Opening', description: 'Open your bank account with us.', price: 'Free of cost' },
        { title: 'All CSC Services', description: 'We provide all services available through the CSC portal. Contact us for more details.' }
      ]
    },
    team: {
      title: 'Meet Our Team',
      members: [
        { name: 'Mohammad Faizan', role: 'Owner' },
        { name: 'Mohammad Shahrukh', role: 'Manager' },
        { name: 'Mohammad Sadiq', role: 'Staff' },
        { name: 'Mohammad Altaf Azam Khan', role: 'Staff' }
      ]
    },
    contact: {
      title: 'Get In Touch',
      address: 'Kohinoor Road, Noor Nagar, Gali No 26',
      email: 'faizanjanseva@gmail.com',
      phone: '8534983041 / 9045174146',
      whatsapp: '8534983041 / 9045174146',
      instagram: '@faizancsc',
      socials: 'Follow Us'
    },
    serviceRequest: {
        title: 'Service Request Form',
        nameLabel: 'Full Name',
        phoneLabel: 'Mobile Number',
        serviceLabel: 'Select Service',
        messageLabel: 'Additional Details (Optional)',
        submitButton: 'Submit Request',
        formDescription: 'Please fill out the form with the mandatory details. After submission, please contact us on one of our numbers for faster processing.',
        thankYouTitle: 'Thank You!',
        thankYouMessage: (requestId: string) => `Your service request has been submitted successfully. Your Request ID is: ${requestId}. Please save this for future reference.`,
        thankYouNote: 'We will process your request shortly. Please contact us for any urgent queries.',
        newRequestButton: 'Submit Another Request'
    },
    statusCheck: {
        title: 'Check Application Status',
        requestIdLabel: 'Enter Your Request ID',
        checkButton: 'Check Status',
        statusResult: (status: string) => `The current status of your application is: ${status}`,
        notFound: 'Request ID not found. Please check the ID and try again.',
        noId: 'Please enter a Request ID.'
    },
    chatbot: {
        title: 'AI Assistant',
        placeholder: 'Ask me anything...'
    }
  },
  [Language.HI]: {
    nav: {
      home: 'होम',
      services: 'सेवाएं',
      team: 'हमारी टीम',
      contact: 'संपर्क करें',
      requestService: 'सेवा का अनुरोध करें',
      checkStatus: 'स्थिति जांचें'
    },
    hero: {
      title: 'मोहम्मद फैजान जन सेवा केंद्र',
      subtitle: 'सभी सीएससी और ई-डिस्ट्रिक्ट सेवाओं के लिए आपका वन-स्टॉप समाधान। विश्वसनीय, तेज और कुशल।',
      cta: 'सेवा का अनुरोध करें'
    },
    services: {
      title: 'हमारी सेवाएं',
      items: [
        { title: 'भारतीय स्टेट बैंक', description: 'जमा, निकासी और खाता खोलने सहित सभी बैंकिंग सेवाएं उपलब्ध हैं।' },
        { title: 'AEPS सेवाएं', description: 'आसान नकद निकासी, बैलेंस पूछताछ और मिनी स्टेटमेंट के लिए आधार सक्षम भुगतान प्रणाली।' },
        { title: 'ई-डिस्ट्रिक्ट सेवाएं', description: 'मूल निवास, जाति और आय प्रमाण पत्र।', price: '₹100 प्रति प्रमाण पत्र' },
        { title: 'लैमिनेशन', description: 'दस्तावेजों के लिए उच्च गुणवत्ता वाला लैमिनेशन।', price: '₹10 प्रति पृष्ठ' },
        { title: 'ज़ेरॉक्स / फोटोकॉपी', description: 'स्पष्ट और तेज़ फोटोकॉपी।', price: '₹1 / प्रति साइड, ₹2 दोनों तरफ के लिए' },
        { title: 'खाता खोलना', description: 'हमारे साथ अपना बैंक खाता खोलें।', price: 'निःशुल्क' },
        { title: 'सभी सीएससी सेवाएं', description: 'हम सीएससी पोर्टल के माध्यम से उपलब्ध सभी सेवाएं प्रदान करते हैं। अधिक जानकारी के लिए हमसे संपर्क करें।' }
      ]
    },
    team: {
      title: 'हमारी टीम से मिलें',
      members: [
        { name: 'मोहम्मद फैजान', role: 'मालिक' },
        { name: 'मोहम्मद शाहरुख', role: 'प्रबंधक' },
        { name: 'मोहम्मद सादिक', role: 'कर्मचारी' },
        { name: 'मोहम्मद अल्ताफ आजम खान', role: 'कर्मचारी' }
      ]
    },
    contact: {
      title: 'संपर्क में रहें',
      address: 'कोहिनूर रोड, नूर नगर, गली नंबर 26',
      email: 'faizanjanseva@gmail.com',
      phone: '8534983041 / 9045174146',
      whatsapp: '8534983041 / 9045174146',
      instagram: '@faizancsc',
      socials: 'हमें फॉलो करें'
    },
     serviceRequest: {
        title: 'सेवा अनुरोध प्रपत्र',
        nameLabel: 'पूरा नाम',
        phoneLabel: 'मोबाइल नंबर',
        serviceLabel: 'सेवा चुनें',
        messageLabel: 'अतिरिक्त विवरण (वैकल्पिक)',
        submitButton: 'अनुरोध जमा करें',
        formDescription: 'कृपया अनिवार्य विवरण के साथ फॉर्म भरें। सबमिट करने के बाद, तेजी से प्रसंस्करण के लिए कृपया हमारे किसी एक नंबर पर हमसे संपर्क करें।',
        thankYouTitle: 'धन्यवाद!',
        thankYouMessage: (requestId: string) => `आपका सेवा अनुरोध सफलतापूर्वक सबमिट कर दिया गया है। आपकी अनुरोध आईडी है: ${requestId}। कृपया इसे भविष्य के संदर्भ के लिए सहेजें।`,
        thankYouNote: 'हम आपके अनुरोध पर शीघ्र ही कार्रवाई करेंगे। किसी भी तत्काल प्रश्न के लिए कृपया हमसे संपर्क करें।',
        newRequestButton: 'एक और अनुरोध सबमिट करें'
    },
    statusCheck: {
        title: 'आवेदन की स्थिति जांचें',
        requestIdLabel: 'अपनी अनुरोध आईडी दर्ज करें',
        checkButton: 'स्थिति जांचें',
        statusResult: (status: string) => `आपके आवेदन की वर्तमान स्थिति है: ${status}`,
        notFound: 'अनुरोध आईडी नहीं मिली। कृपया आईडी जांचें और फिर से प्रयास करें।',
        noId: 'कृपया एक अनुरोध आईडी दर्ज करें।'
    },
    chatbot: {
        title: 'एआई सहायक',
        placeholder: 'मुझसे कुछ भी पूछें...'
    }
  }
};
