
import React, { useState, useCallback } from 'react';
import { Language, ServiceRequest as ServiceRequestType } from './types';
import { translations } from './constants';
import Header from './components/Header';
import Section from './components/Section';
import Contact from './components/Contact';
import ServiceRequest from './components/ServiceRequest';
import Chatbot from './components/Chatbot';

const App: React.FC = () => {
  const [language, setLanguage] = useState<Language>(Language.EN);
  const [serviceRequests, setServiceRequests] = useState<ServiceRequestType[]>([]);

  const t = translations[language];

  const handleNavigate = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    section?.scrollIntoView({ behavior: 'smooth' });
  };

  const addRequest = useCallback((requestData: Omit<ServiceRequestType, 'id' | 'status'>): string => {
    const newId = `MFSK-${Date.now()}`;
    const newRequest: ServiceRequestType = {
      ...requestData,
      id: newId,
      status: 'Pending',
    };
    setServiceRequests(prev => [...prev, newRequest]);
    return newId;
  }, []);

  const getRequestStatus = useCallback((id: string): string => {
    const request = serviceRequests.find(r => r.id.toLowerCase() === id.toLowerCase());
    if (request) {
      return t.statusCheck.statusResult(request.status);
    }
    return t.statusCheck.notFound;
  }, [serviceRequests, t]);

  return (
    <div className="bg-gray-100 text-gray-800 font-sans">
      <Header language={language} setLanguage={setLanguage} translations={t} onNavigate={handleNavigate} />
      
      <main>
        {/* Hero Section */}
        <Section id="home" className="bg-cover bg-center text-white" style={{backgroundImage: "url('https://picsum.photos/1920/1080?grayscale&blur=2')"}}>
            <div className="bg-black bg-opacity-50 py-20 md:py-32 text-center">
                 <h2 className="text-4xl md:text-6xl font-extrabold">{t.hero.title}</h2>
                <p className="mt-4 text-lg md:text-xl max-w-3xl mx-auto">{t.hero.subtitle}</p>
                <button onClick={() => handleNavigate('request-service')} className="mt-8 bg-blue-600 text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-blue-700 transition-transform transform hover:scale-105">
                    {t.hero.cta}
                </button>
            </div>
        </Section>
        
        {/* Services Section */}
        <Section id="services" className="bg-white">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">{t.services.title}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {t.services.items.map((service, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-lg shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
                <h3 className="text-xl font-semibold text-blue-800">{service.title}</h3>
                <p className="mt-2 text-gray-600">{service.description}</p>
                {service.price && <p className="mt-4 font-bold text-blue-700">{service.price}</p>}
              </div>
            ))}
          </div>
        </Section>

        {/* Team Section */}
        <Section id="team" className="bg-gray-50">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">{t.team.title}</h2>
          <div className="flex flex-wrap justify-center gap-8">
            {t.team.members.map((member, index) => (
              <div key={index} className="text-center">
                <img src={`https://picsum.photos/200/200?random=${index}`} alt={member.name} className="w-32 h-32 rounded-full mx-auto mb-4 shadow-lg"/>
                <h3 className="text-lg font-semibold text-gray-800">{member.name}</h3>
                <p className="text-gray-600">{member.role}</p>
              </div>
            ))}
          </div>
        </section>

        <ServiceRequest 
          translations={{
            nav: t.nav,
            services: t.services,
            serviceRequest: t.serviceRequest,
            statusCheck: t.statusCheck
          }} 
          addRequest={addRequest} 
          getRequestStatus={getRequestStatus} 
        />

        <Contact translations={t.contact} />
      </main>

      <Chatbot translations={t.chatbot} />

      <footer className="bg-gray-800 text-white py-6">
        <div className="container mx-auto px-4 text-center">
            <p>&copy; {new Date().getFullYear()} Mohammad Faizan Jan Seva Kendra. All Rights Reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;