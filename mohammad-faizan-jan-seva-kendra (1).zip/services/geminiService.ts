import { GoogleGenAI } from "@google/genai";

// FIX: Per coding guidelines, API key is assumed to be present in environment variables, so conditional checks are removed.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const getGeminiResponse = async (prompt: string): Promise<string> => {
  try {
    // FIX: Refactored to use systemInstruction for context and pass the user prompt directly as contents, which is a better practice.
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: `You are a helpful assistant for a Common Service Centre named "Mohammad Faizan Jan Seva Kendra". Answer questions related to their services, but do not answer questions outside of this scope.`,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Error fetching from Gemini API:", error);
    return "Sorry, I'm having trouble connecting to the AI service right now.";
  }
};
