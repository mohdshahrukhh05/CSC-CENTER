
export enum Language {
  EN = 'en',
  HI = 'hi'
}

export interface TranslationContent {
  nav: {
    home: string;
    services: string;
    team: string;
    contact: string;
    requestService: string;
    checkStatus: string;
  };
  hero: {
    title: string;
    subtitle: string;
    cta: string;
  };
  services: {
    title: string;
    items: { title: string; description: string; price?: string }[];
  };
  team: {
    title: string;
    members: { name: string; role: string }[];
  };
  contact: {
    title: string;
    address: string;
    email: string;
    phone: string;
    whatsapp: string;
    instagram: string;
    socials: string;
  };
  serviceRequest: {
    title: string;
    nameLabel: string;
    phoneLabel: string;
    serviceLabel: string;
    messageLabel: string;
    submitButton: string;
    formDescription: string;
    thankYouTitle: string;
    thankYouMessage: (requestId: string) => string;
    thankYouNote: string;
    newRequestButton: string;
  };
  statusCheck: {
    title: string;
    requestIdLabel: string;
    checkButton: string;
    statusResult: (status: string) => string;
    notFound: string;
    noId: string;
  };
  chatbot: {
    title: string;
    placeholder: string;
  };
}

export interface ServiceRequestTranslations {
  nav: TranslationContent['nav'];
  services: TranslationContent['services'];
  serviceRequest: TranslationContent['serviceRequest'];
  statusCheck: TranslationContent['statusCheck'];
}

export type Translations = {
  [key in Language]: TranslationContent;
};

export interface ServiceRequest {
  id: string;
  name: string;
  phone: string;
  service: string;
  message: string;
  status: 'Pending' | 'In Progress' | 'Completed' | 'Rejected';
}