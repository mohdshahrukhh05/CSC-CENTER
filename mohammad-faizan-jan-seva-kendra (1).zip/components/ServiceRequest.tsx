
import React, { useState } from 'react';
import { ServiceRequestTranslations, ServiceRequest as ServiceRequestType } from '../types';
import Section from './Section';

interface ServiceRequestProps {
  translations: ServiceRequestTranslations;
  addRequest: (request: Omit<ServiceRequestType, 'id' | 'status'>) => string;
  getRequestStatus: (id: string) => string;
}

const ServiceRequest: React.FC<ServiceRequestProps> = ({ translations, addRequest, getRequestStatus }) => {
  const [activeTab, setActiveTab] = useState<'form' | 'status'>('form');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [service, setService] = useState('');
  const [message, setMessage] = useState('');
  const [submittedRequestId, setSubmittedRequestId] = useState<string | null>(null);

  const [checkId, setCheckId] = useState('');
  const [statusResult, setStatusResult] = useState('');

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && phone && service) {
      const newRequestId = addRequest({ name, phone, service, message });
      setSubmittedRequestId(newRequestId);
      setName('');
      setPhone('');
      setService('');
      setMessage('');
    }
  };
  
  const handleStatusCheck = (e: React.FormEvent) => {
      e.preventDefault();
      if(checkId.trim()){
        const status = getRequestStatus(checkId.trim());
        setStatusResult(status);
      } else {
        setStatusResult(translations.statusCheck.noId)
      }
  };

  const handleNewRequest = () => {
    setSubmittedRequestId(null);
    setActiveTab('form');
  };

  const renderForm = () => {
    if (submittedRequestId) {
      return (
        <div className="text-center p-8 bg-green-50 border border-green-200 rounded-lg">
          <h3 className="text-2xl font-bold text-green-800">{translations.serviceRequest.thankYouTitle}</h3>
          <p className="mt-4 text-gray-700">{translations.serviceRequest.thankYouMessage(submittedRequestId)}</p>
          <p className="mt-2 text-sm text-gray-600">{translations.serviceRequest.thankYouNote}</p>
          <button
            onClick={handleNewRequest}
            className="mt-6 bg-blue-600 text-white px-6 py-2 rounded-md font-medium hover:bg-blue-700 transition-colors"
          >
            {translations.serviceRequest.newRequestButton}
          </button>
        </div>
      );
    }

    return (
      <form onSubmit={handleFormSubmit} className="space-y-6">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">{translations.serviceRequest.nameLabel}</label>
          <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"/>
        </div>
        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-gray-700">{translations.serviceRequest.phoneLabel}</label>
          <input type="tel" id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"/>
        </div>
        <div>
          <label htmlFor="service" className="block text-sm font-medium text-gray-700">{translations.serviceRequest.serviceLabel}</label>
          <select id="service" value={service} onChange={(e) => setService(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
            <option value="" disabled>Select a service</option>
            {translations.services.items.map(item => <option key={item.title} value={item.title}>{item.title}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="message" className="block text-sm font-medium text-gray-700">{translations.serviceRequest.messageLabel}</label>
          <textarea id="message" value={message} onChange={(e) => setMessage(e.target.value)} rows={4} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"></textarea>
        </div>
        <p className="text-sm text-gray-500">{translations.serviceRequest.formDescription}</p>
        <button type="submit" className="w-full bg-blue-600 text-white py-3 px-4 rounded-md font-semibold hover:bg-blue-700 transition-colors">{translations.serviceRequest.submitButton}</button>
      </form>
    );
  };
  
  const renderStatusCheck = () => {
      return (
          <form onSubmit={handleStatusCheck} className="space-y-4">
              <div>
                  <label htmlFor="request-id" className="block text-sm font-medium text-gray-700">{translations.statusCheck.requestIdLabel}</label>
                  <input type="text" id="request-id" value={checkId} onChange={e => setCheckId(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"/>
              </div>
              <button type="submit" className="w-full bg-blue-600 text-white py-3 px-4 rounded-md font-semibold hover:bg-blue-700 transition-colors">{translations.statusCheck.checkButton}</button>
              {statusResult && <p className="mt-4 text-center text-gray-700 p-4 bg-gray-100 rounded-md">{statusResult}</p>}
          </form>
      );
  }

  return (
    <Section id="request-service" className="bg-white">
      <div className="max-w-2xl mx-auto">
        <div className="mb-8 border-b border-gray-200">
          <nav className="-mb-px flex space-x-8" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('form')}
              className={`${activeTab === 'form' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {translations.nav.requestService}
            </button>
            <button
              onClick={() => setActiveTab('status')}
              className={`${activeTab === 'status' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {translations.nav.checkStatus}
            </button>
          </nav>
        </div>
        <div className="bg-gray-50 p-6 sm:p-8 rounded-lg shadow-sm">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
            {activeTab === 'form' ? translations.serviceRequest.title : translations.statusCheck.title}
          </h2>
          {activeTab === 'form' ? renderForm() : renderStatusCheck()}
        </div>
      </div>
    </Section>
  );
};

export default ServiceRequest;