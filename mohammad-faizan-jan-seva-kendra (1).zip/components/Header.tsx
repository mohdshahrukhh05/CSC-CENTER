
import React from 'react';
import { Language, TranslationContent } from '../types';

interface HeaderProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  translations: TranslationContent;
  onNavigate: (sectionId: string) => void;
}

const Header: React.FC<HeaderProps> = ({ language, setLanguage, translations, onNavigate }) => {
  
  const toggleLanguage = () => {
    setLanguage(language === Language.EN ? Language.HI : Language.EN);
  };

  const navItems = [
    { id: 'home', label: translations.nav.home },
    { id: 'services', label: translations.nav.services },
    { id: 'team', label: translations.nav.team },
    { id: 'contact', label: translations.nav.contact },
  ];

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0">
            <h1 className="text-xl font-bold text-blue-800 cursor-pointer" onClick={() => onNavigate('home')}>
              M.F. Jan Seva Kendra
            </h1>
          </div>
          <nav className="hidden md:flex items-center space-x-8">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className="text-gray-600 hover:text-blue-700 font-medium transition-colors"
              >
                {item.label}
              </button>
            ))}
          </nav>
          <div className="flex items-center space-x-4">
            <button
              onClick={toggleLanguage}
              className="px-3 py-1.5 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
            >
              {language === Language.EN ? 'हिन्दी' : 'English'}
            </button>
            <button
              onClick={() => onNavigate('request-service')}
              className="hidden sm:inline-block bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 transition-colors"
            >
              {translations.nav.requestService}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
